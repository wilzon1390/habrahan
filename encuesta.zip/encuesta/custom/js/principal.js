
$(document).ready(function() {
	$('#navHome').addClass('active');
});
