// global variable
var manageMemberTable;

$(document).ready(function() {
	
	manageMemberTable = $("#manageMemberTable").DataTable({
		'ajax': 'index.php/ccuestionario/fetchMemberData',
		'orders': []
	});	
});

function addMemberModel(){
}

function editMember(id = null){
}