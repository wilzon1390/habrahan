
	<!-- jquery -->
	<script type="text/javascript" src="assets/jquery/jquery.min.js"></script>
	<!-- bootstrap js -->
	<script type="text/javascript" src="assets/bootstrap/js/bootstrap.min.js"></script>
	<!-- datatables -->
	<script type="text/javascript" src="assets/datatables/datatables.min.js"></script>

	<!-- custom js -->
	<?php if($this->uri->segment(1)=='crespuesta'){?>
		<script type="text/javascript" src="custom/js/respuesta.js"></script>
	<?php }?>
	<?php if($this->uri->segment(1)=='ccomponente'){?>
		<script type="text/javascript" src="custom/js/componente.js"></script>
	<?php }?>
	<?php if($this->uri->segment(1)=='ccriterio'){?>
		<script type="text/javascript" src="custom/js/criterio.js"></script>
	<?php }?>
	<?php if($this->uri->segment(1)=='cindicador'){?>
		<script type="text/javascript" src="custom/js/indicador.js"></script>
	<?php }?>
	<?php if($this->uri->segment(1)=='cpregunta'){?>
		<script type="text/javascript" src="custom/js/pregunta.js"></script>
	<?php }?>
	<?php if($this->uri->segment(1)=='welcome'){?>
		<script type="text/javascript" src="custom/js/home.js"></script>
	<?php }?>
	<?php if($this->uri->segment(1)=='cprincipal'){?>
		<script type="text/javascript" src="custom/js/principal.js"></script>
	<?php }?>
</body>
</html>