<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="utf-8">

	<title>Admin</title>
	<!-- bootstrap -->
	<link rel="stylesheet" type="text/css" href="assets/bootstrap/css/bootstrap.min.css">
	<!-- datatables css -->
	<link rel="stylesheet" type="text/css" href="assets/datatables/datatables.min.css">

</head>
<body>

	<nav class="navbar navbar-default navbar-static-top">
	 <div class="container">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>      
    </div>
    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">      

      <ul class="nav navbar-nav navbar-right">        

      	<li id="navHome"><a href="<?= base_url().'cprincipal';?>"><i class="glyphicon glyphicon-home"></i>  Principal</a></li>
        
        <li id="navDim"><a href="<?= base_url().'welcome';?>"><i class="glyphicon glyphicon-th-large"></i> Dimensión</a></li>

        <li id="navComp"><a href="<?= base_url().'ccomponente';?>"> <i class="glyphicon glyphicon-th"></i> Componente</a></li>

        <li id="navCri"><a href="<?= base_url().'ccriterio';?>"> <i class="glyphicon glyphicon-th-list"></i> Criterio</a></li>

        <li id="navInd"><a href="<?= base_url().'cindicador';?>"> <i class="glyphicon glyphicon-tags"></i> Indicador</a></li>

        <li id="navPreg"><a href="<?= base_url().'cpregunta';?>"> <i class="glyphicon glyphicon-list-alt"></i> Preguntas </a></li>

        <li id="navRes"><a href="<?= base_url().'crespuesta';?>"> <i class="glyphicon glyphicon-ok"></i> Respuestas </a></li>

        <li class="dropdown" id="navSetting">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"> <i class="glyphicon glyphicon-user"></i> <span class="caret"></span></a>
          <ul class="dropdown-menu">            
            <li id="topNavLogout"><a href="#"> <i class="glyphicon glyphicon-log-out"></i> Salir</a></li>            
          </ul>
        </li>
               
      </ul>
     </div><!-- /.navbar-collapse -->
    </div><!-- /.container-fluid -->
	</nav>