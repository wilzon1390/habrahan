<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Cuestionario</title>
	<!-- bootstrap -->
	<link rel="stylesheet" type="text/css" href="assets/bootstrap/css/bootstrap.min.css">
	<!-- datatables css -->
	<link rel="stylesheet" type="text/css" href="assets/datatables/datatables.min.css">
	<!--Stilo de radio buton--->
	<style type="text/css">
		label {
		  font-weight: normal!important;
		}

		.ra{
		  -webkit-appearance: none;
		  -moz-appearance: none;
		  appearance: none;

		  border-radius: 50%;
		  width: 16px;
		  height: 16px;

		  border: 2px solid #999;
		  transition: 0.2s all linear;
		  outline: none;
		  margin-right: 5px;

		  position: relative;
		  top: 4px;
		}

		input:checked {
		  border: 6px solid green;
		}
	</style>
</head>
<body>
	<nav class="navbar navbar-default navbar-static-top">
		<div class="container">
	    <!-- Brand and toggle get grouped for better mobile display -->
	    <div class="navbar-header">
	      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
	        <span class="sr-only">Toggle navigation</span>
	        <span class="icon-bar"></span>
	        <span class="icon-bar"></span>
	        <span class="icon-bar"></span>
	      </button>      
	    </div>

	    <!-- Collect the nav links, forms, and other content for toggling -->
	    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">      

	      <ul class="nav navbar-nav navbar-right">

	        <li class="dropdown" id="navSetting">
	          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"> <i class="glyphicon glyphicon-user"></i> <span class="caret"></span></a>
	          <ul class="dropdown-menu">            
	            <li id="topNavLogout"><a href="#"> <i class="glyphicon glyphicon-log-out"></i> Salir</a></li>            
	          </ul>
	        </li>
	               
	      </ul>
	    </div><!-- /.navbar-collapse -->
	  </div><!-- /.container-fluid -->
	</nav>

	<div class="container">


	<div class="row">
		<div class="col-md-12">

			<ol class="breadcrumb">
			  <li><a href="#">Cuestionario</a></li>		  
			</ol>

			<div class="panel panel-default">
				<div class="panel-heading">
					<div class="page-heading"> <i class="glyphicon glyphicon-edit"></i> Seleccione las respuestas</div>
				</div> <!-- /panel-heading -->
				<div class="panel-body">
					
				<form id="historialForm" name="historialForm" action="#" method="POST">
					<div class="div-action pull pull-right" style="padding-bottom:20px;">
						<button type="submit" class="btn btn-success button1" id="confirmar"> <i class="glyphicon glyphicon-send"></i> Enviar </button>
					</div>
					<table class="table" id="manageMemberTable">
						<thead>
							<tr>							
								<th>N°</th>
								<th>Pregunta</th>			
								<th>Respuesta</th>
							</tr>
						</thead>						
					</table>
				</form>

				</div> <!-- /panel-body -->
			</div> <!-- /panel -->		
		</div> <!-- /col-md-12 -->
	</div> <!-- /row -->
	</div> 

	<!-- jquery -->
	<script type="text/javascript" src="assets/jquery/jquery.min.js"></script>
	<!-- bootstrap js -->
	<script type="text/javascript" src="assets/bootstrap/js/bootstrap.min.js"></script>
	<!-- datatables -->
	<script type="text/javascript" src="assets/datatables/datatables.min.js"></script>
	<!-- custom js -->
	<script type="text/javascript" src="custom/js/cuestionario.js"></script>
</body>
</html>