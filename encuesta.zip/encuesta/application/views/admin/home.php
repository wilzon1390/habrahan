	<div class="container">

		<div class="page-header">
		  <center><h1>CRUD - <small>Dimensión</small></h1></center>
		</div>

		<div class="messages"></div>

		<button class="btn btn-default pull pull-right" data-toggle="modal" data-target="#addMember" onclick="addMemberModel()">
			Nueva dimensión
		</button>

		<br /> <br />

		<table class="table table-bordered" id="manageMemberTable">
			<thead>
				<tr>
					<th>ID</th>
					<th>Dimensión</th>
					<th>Valor</th>
					<th>Estado</th>
					<th>Opción</th>
				</tr>
			</thead>
		</table>
	</div>

	<!-- add member -->
	<div class="modal fade" tabindex="-1" role="dialog" id="addMember">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title">Nueva dimensión</h4>
      </div>
      <form method="post" action="index.php/welcome/create" id="createForm">
      <div class="modal-body">        
			  <div class="form-group">
			    <label for="txtDimension">Dimensión * </label>
			    <input type="text" class="form-control" id="txtDimension" name="txtDimension" placeholder="Ingrese nombre de Dimensión">
			  </div>
			  <div class="form-group">
			    <label for="txtValor">Valor</label>
			    <input type="text" class="form-control" id="txtValor" name="txtValor" placeholder="Ingrese un valor">
			  </div>			  
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Cerrar</button>
        <button type="submit" class="btn btn-primary">Guardar cambios</button>
      </div>
      </form>
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->
	<!-- /add mmebers -->

	<!-- edit member -->
	<div class="modal fade" tabindex="-1" role="dialog" id="editMemberModal">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title">Editar dimensión</h4>
      </div>
      <form method="post" action="index.php/welcome/edit" id="editForm">
      <div class="modal-body">        
			  <div class="form-group">
			    <label for="editDimension">Dimension * </label>
			    <input type="text" class="form-control" id="editDimension" name="editDimension" placeholder="Ingrese nombre de dimensión">
			  </div>
			  <div class="form-group">
			    <label for="editValor">Valor</label>
			    <input type="text" class="form-control" id="editValor" name="editValor" placeholder="Ingrese un valor">
			  </div>			  
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Cerrar</button>
        <button type="submit" class="btn btn-primary">Guardar cambios</button>
      </div>
      </form>
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->
	<!-- /edit mmebers -->

<!-- removeMember -->
<div class="modal fade" tabindex="-1" role="dialog" id="removeMemberModal">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title">Eliminar</h4>
      </div>
      <div class="modal-body">
        <p>¿Realmente quieres eliminar ?</p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Cerrar</button>
        <button type="button" id="removeMemberBtn" class="btn btn-primary">Guardar cambios</button>
      </div>
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->