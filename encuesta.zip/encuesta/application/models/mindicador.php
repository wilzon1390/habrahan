<?php 

/**
* 
*/
class Mindicador extends CI_Model
{
	public function create() 
	{
		$data = array(
			'nom_in' => $this->input->post('txtIndicador'),
			'valor_in' => $this->input->post('txtValor'),
			'id_cri' => $this->input->post('cboCriterio')
		);

		$sql = $this->db->insert('indicador', $data);

		if($sql === true) {
			return true; 
		} else {
			return false;
		}
	} // /create function

	public function edit($id = null) 
	{
		if($id) {
			$data = array(
				'nom_in' => $this->input->post('editIndicador'),
				'valor_in' => $this->input->post('editValor'),
				'id_cri' => $this->input->post('editCboCriterio')
			);

			$this->db->where('id_in', $id);
			$sql = $this->db->update('indicador', $data);

			if($sql === true) {
				return true; 
			} else {
				return false;
			}
		}
			
	}

	public function fetchMemberData($id = null) 
	{
		if($id) {
			$sql = "SELECT * FROM indicador,criterio WHERE id_in = ? AND indicador.id_cri=criterio.id_cri";
			$query = $this->db->query($sql, array($id));
			return $query->row_array();
		}

		$sql = "SELECT * FROM indicador,criterio WHERE indicador.id_cri=criterio.id_cri";
		$query = $this->db->query($sql);
		return $query->result_array();
	}

	public function remove($id = null) {
		if($id) {
			$sql = "DELETE FROM indicador WHERE id_in = ?";
			$query = $this->db->query($sql, array($id));

			// ternary operator
			return ($query === true) ? true : false;			
		} // /if
	}
	
}