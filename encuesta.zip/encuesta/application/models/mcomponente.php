<?php 

/**
* 
*/
class Mcomponente extends CI_Model
{
	public function create() 
	{
		$data = array(
			'nom_com' => $this->input->post('txtComponente'),
			'valor_com' => $this->input->post('txtValor'),
			'id_dim' => $this->input->post('cboDimension')
		);

		$sql = $this->db->insert('componente', $data);

		if($sql === true) {
			return true; 
		} else {
			return false;
		}
	} // /create function

	public function edit($id = null) 
	{
		if($id) {
			$data = array(
				'nom_com' => $this->input->post('editComponente'),
				'valor_com' => $this->input->post('editValor'),
				'id_dim' => $this->input->post('editCboDimension')
			);

			$this->db->where('id_com', $id);
			$sql = $this->db->update('componente', $data);

			if($sql === true) {
				return true; 
			} else {
				return false;
			}
		}
			
	}

	public function fetchMemberData($id = null) 
	{
		if($id) {
			$sql = "SELECT * FROM componente,dimension WHERE id_com = ? AND componente.id_dim=dimension.id_dim";
			$query = $this->db->query($sql, array($id));
			return $query->row_array();
		}

		$sql = "SELECT * FROM componente,dimension WHERE componente.id_dim=dimension.id_dim";
		$query = $this->db->query($sql);
		return $query->result_array();
	}

	public function fetchMemberData2($id = null) 
	{
		if($id) {
			$sql = "SELECT * FROM componente WHERE id_dim = ? AND estado_com=1";
			$query = $this->db->query($sql, array($id));
			return $query->num_rows();
		}

		$sql = "SELECT * FROM dimension WHERE estado_dim = 1";
		$query = $this->db->query($sql);
		return $query->result_array();
	}

	public function remove($id = null) {
		if($id) {
			$sql = "DELETE FROM componente WHERE id_com = ?";
			$query = $this->db->query($sql, array($id));

			// ternary operator
			return ($query === true) ? true : false;			
		} // /if
	}
	
}