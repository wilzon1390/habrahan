<?php 
	/**
	 * 
	 */
	class Mcombo5 extends CI_Model
	{
		
		function __construct()
		{
			parent::__construct();
		}

		public function getCombo5($s){
			$s = $this->db->get_where('preguntas',array('estado_preg' => $s));
			return $s->result();
		}
	}
?>