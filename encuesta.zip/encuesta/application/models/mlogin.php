<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Mlogin extends CI_Model {

	function login($email, $password){
		$this->db->where("nomUsuario", $email);
		$this->db->where("clave", $password);
		$resultados = $this->db->get("usuario");
		if ($resultados->num_rows()>0) {
			return $resultados->row();
		}
		else{
			return false;
		}
	}
}