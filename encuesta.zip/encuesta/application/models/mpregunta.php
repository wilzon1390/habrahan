<?php 

/**
* 
*/
class Mpregunta extends CI_Model
{
	public function create() 
	{
		$data = array(
			'nom_preg' => $this->input->post('txtPregunta'),
			'valor_preg' => $this->input->post('txtValor'),
			'id_in' => $this->input->post('cboIndicador'),
			'dirigido_preg' => $this->input->post('cboDirigido')
		);

		$sql = $this->db->insert('preguntas', $data);

		if($sql === true) {
			return true; 
		} else {
			return false;
		}
	} // /create function

	public function edit($id = null) 
	{
		if($id) {
			$data = array(
				'nom_preg' => $this->input->post('editPregunta'),
				'valor_preg' => $this->input->post('editValor'),
				'id_in' => $this->input->post('editCboIndicador'),
				'dirigido_preg' => $this->input->post('editCboDirigido')
			);

			$this->db->where('id_preg', $id);
			$sql = $this->db->update('preguntas', $data);

			if($sql === true) {
				return true; 
			} else {
				return false;
			}
		}
			
	}

	public function fetchMemberData($id = null) 
	{
		if($id) {
			$sql = "SELECT * FROM indicador,preguntas WHERE id_preg = ? AND indicador.id_in=preguntas.id_in";
			$query = $this->db->query($sql, array($id));
			return $query->row_array();
		}

		$sql = "SELECT * FROM indicador,preguntas WHERE indicador.id_in=preguntas.id_in";
		$query = $this->db->query($sql);
		return $query->result_array();
	}

	public function remove($id = null) {
		if($id) {
			$sql = "DELETE FROM preguntas WHERE id_preg = ?";
			$query = $this->db->query($sql, array($id));

			// ternary operator
			return ($query === true) ? true : false;			
		} // /if
	}
	
}