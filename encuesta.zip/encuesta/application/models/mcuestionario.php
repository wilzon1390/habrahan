<?php 

/**
* 
*/
class Mcuestionario extends CI_Model
{
	public function create(){
	} // /create function

	public function edit($id = null){		
	}

	public function fetchMemberData() 
	{
		$sql = "SELECT * FROM preguntas WHERE estado_preg=1";
		$query = $this->db->query($sql);
		return $query->result_array();
	}

	public function fetchMemberData2($id = null) 
	{
		$sql = "SELECT * FROM respuesta WHERE id_preg = ?";
		$query = $this->db->query($sql, array($id));
		return $query->result_array();
	}

	public function remove($id = null){
	}
	
}