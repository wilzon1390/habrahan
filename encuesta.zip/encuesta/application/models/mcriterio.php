<?php 

/**
* 
*/
class Mcriterio extends CI_Model
{
	public function create() 
	{
		$data = array(
			'nom_cri' => $this->input->post('txtCriterio'),
			'valor_cri' => $this->input->post('txtValor'),
			'id_com' => $this->input->post('cboComponente')
		);

		$sql = $this->db->insert('criterio', $data);

		if($sql === true) {
			return true; 
		} else {
			return false;
		}
	} // /create function

	public function edit($id = null) 
	{
		if($id) {
			$data = array(
				'nom_cri' => $this->input->post('editCriterio'),
				'valor_cri' => $this->input->post('editValor'),
				'id_com' => $this->input->post('editCboComponente')
			);

			$this->db->where('id_cri', $id);
			$sql = $this->db->update('criterio', $data);

			if($sql === true) {
				return true; 
			} else {
				return false;
			}
		}
			
	}

	public function fetchMemberData($id = null) 
	{
		if($id) {
			$sql = "SELECT * FROM componente,criterio WHERE id_cri = ? AND componente.id_com=criterio.id_com";
			$query = $this->db->query($sql, array($id));
			return $query->row_array();
		}

		$sql = "SELECT * FROM componente,criterio WHERE componente.id_com=criterio.id_com";
		$query = $this->db->query($sql);
		return $query->result_array();
	}

	public function remove($id = null) {
		if($id) {
			$sql = "DELETE FROM criterio WHERE id_cri = ?";
			$query = $this->db->query($sql, array($id));

			// ternary operator
			return ($query === true) ? true : false;			
		} // /if
	}
	
}