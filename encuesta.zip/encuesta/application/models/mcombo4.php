<?php 
	/**
	 * 
	 */
	class Mcombo4 extends CI_Model
	{
		
		function __construct()
		{
			parent::__construct();
		}

		public function getCombo4($s){
			$s = $this->db->get_where('indicador',array('estado_in' => $s));
			return $s->result();
		}
	}
?>