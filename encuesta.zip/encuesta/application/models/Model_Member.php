<?php 

/**
* 
*/
class Model_Member extends CI_Model
{
	public function create() 
	{
		$data = array(
			'nom_dim' => $this->input->post('txtDimension'),
			'valor_dim' => $this->input->post('txtValor')
		);

		$sql = $this->db->insert('dimension', $data);

		if($sql === true) {
			return true; 
		} else {
			return false;
		}
	} // /create function

	public function edit($id = null) 
	{
		if($id) {
			$data = array(
				'nom_dim' => $this->input->post('editDimension'),
				'valor_dim' => $this->input->post('editValor')				
			);

			$this->db->where('id_dim', $id);
			$sql = $this->db->update('dimension', $data);

			if($sql === true) {
				return true; 
			} else {
				return false;
			}
		}
			
	}

	public function fetchMemberData($id = null) 
	{
		if($id) {
			$sql = "SELECT * FROM dimension WHERE id_dim = ?";
			$query = $this->db->query($sql, array($id));
			return $query->row_array();
		}

		$sql = "SELECT * FROM dimension";
		$query = $this->db->query($sql);
		return $query->result_array();
	}

	public function remove($id = null) {
		if($id) {
			$sql = "DELETE FROM dimension WHERE id_dim = ?";
			$query = $this->db->query($sql, array($id));

			// ternary operator
			return ($query === true) ? true : false;			
		} // /if
	}
	
}