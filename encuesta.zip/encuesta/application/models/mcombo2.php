<?php 
	/**
	 * 
	 */
	class Mcombo2 extends CI_Model
	{
		
		function __construct()
		{
			parent::__construct();
		}

		public function getCombo2($s){
			$s = $this->db->get_where('componente',array('estado_com' => $s));
			return $s->result();
		}
	}
?>