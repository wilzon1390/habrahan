<?php 

/**
* 
*/
class Mrespuesta extends CI_Model
{
	public function create() 
	{
		$data = array(
			'nom_res' => $this->input->post('txtRespuesta'),
			'valor_res' => $this->input->post('txtValor'),
			'id_preg' => $this->input->post('cboPregunta')
		);

		$sql = $this->db->insert('respuesta', $data);

		if($sql === true) {
			return true; 
		} else {
			return false;
		}
	} // /create function

	public function edit($id = null) 
	{
		if($id) {
			$data = array(
				'nom_res' => $this->input->post('editRespuesta'),
				'valor_res' => $this->input->post('editValor'),
				'id_preg' => $this->input->post('editCboPregunta')
			);

			$this->db->where('id_res', $id);
			$sql = $this->db->update('respuesta', $data);

			if($sql === true) {
				return true; 
			} else {
				return false;
			}
		}
			
	}

	public function fetchMemberData($id = null) 
	{
		if($id) {
			$sql = "SELECT * FROM respuesta,preguntas WHERE id_res = ? AND respuesta.id_preg=preguntas.id_preg";
			$query = $this->db->query($sql, array($id));
			return $query->row_array();
		}

		$sql = "SELECT * FROM respuesta,preguntas WHERE respuesta.id_preg=preguntas.id_preg";
		$query = $this->db->query($sql);
		return $query->result_array();
	}

	public function remove($id = null) {
		if($id) {
			$sql = "DELETE FROM respuesta WHERE id_res = ?";
			$query = $this->db->query($sql, array($id));

			// ternary operator
			return ($query === true) ? true : false;			
		} // /if
	}
	
}