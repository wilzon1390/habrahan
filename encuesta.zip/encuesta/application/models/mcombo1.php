<?php 
	/**
	 * 
	 */
	class Mcombo1 extends CI_Model
	{
		
		function __construct()
		{
			parent::__construct();
		}

		public function getCombo1($s){
			$s = $this->db->get_where('dimension',array('estado_dim' => $s));
			return $s->result();
		}
	}
?>