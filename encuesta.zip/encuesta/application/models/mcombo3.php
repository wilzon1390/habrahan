<?php 
	/**
	 * 
	 */
	class Mcombo3 extends CI_Model
	{
		
		function __construct()
		{
			parent::__construct();
		}

		public function getCombo3($s){
			$s = $this->db->get_where('criterio',array('estado_cri' => $s));
			return $s->result();
		}
	}
?>