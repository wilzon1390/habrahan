<?php
	/**
	 * 
	 */
	class Ccombo2 extends CI_Controller
	{
		
		function __construct()
		{
			parent::__construct();
			$this->load->model('mcombo2');
		}

		public function getCombo2(){
			$s = $this->input->post('estado_com');
			$resultado = $this->mcombo2->getCombo2($s);

			echo json_encode($resultado);
		}
	}
?>