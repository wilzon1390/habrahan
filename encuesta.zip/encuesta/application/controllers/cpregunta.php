<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Cpregunta extends CI_Controller {

	public function __construct() {
		parent::__construct();

		//form -validation
		$this->load->library('form_validation');

		$this->load->model('mpregunta');
	}

	public function index()
	{
		$this->load->view('layout/header');
		$this->load->view('admin/vpregunta');
		$this->load->view('layout/footer');
	}

	public function create() 
	{

		$validator = array('success' => false, 'messages' => array());

		$config = array(
	    array(
        'field' => 'txtPregunta',
        'label' => 'Pregunta',
        'rules' => 'trim|required'
	    )
		);

		$this->form_validation->set_rules($config);
		$this->form_validation->set_error_delimiters('<p class="text-danger">','</p>');

		if($this->form_validation->run() === true) {

			$createMember = $this->mpregunta->create(); 

			if($createMember === true) {
				$validator['success'] = true;
				$validator['messages'] = "Agregado exitosamente";
			} else {
				$validator['success'] = false;
				$validator['messages'] = "Error al actualizar la información";
			}			
		} 
		else {
			$validator['success'] = false;
			foreach ($_POST as $key => $value) {
				$validator['messages'][$key] = form_error($key);	
			}			
		}

		echo json_encode($validator);
	}

	public function fetchMemberData() 
	{
		$result = array('data' => array());

		$data = $this->mpregunta->fetchMemberData();
		foreach ($data as $key => $value) {

			// active 
		 	if($value['estado_preg'] == 0) {
		 		// deactivate dimension
		 		$estado = "<label class='label label-danger'>Inactivo</label>"; 		
		 	} else { 		
		 		// activate dimension
		 		$estado = "<label class='label label-success'>Activo</label>";
		 	}
		 	//dirigido
		 	if($value['dirigido_preg'] == 1) $dirigido="Estudiante";
		 	else $dirigido="Docente";
			// button
			$buttons = '
			<div class="btn-group">
			  <button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
			    Acción <span class="caret"></span>
			  </button>
			  <ul class="dropdown-menu">
			    <li><a type="button" onclick="editMember('.$value['id_preg'].')" data-toggle="modal" data-target="#editMemberModal">Editar</a></li>
			    <li><a type="button" onclick="removeMember('.$value['id_preg'].')" data-toggle="modal" data-target="#removeMemberModal">Eliminar</a></li>			    
			  </ul>
			</div>
			';

			$result['data'][$key] = array(
				$value['id_preg'],
				$value['nom_in'],
				$dirigido,
				$value['nom_preg'],
				$value['valor_preg'],
				$estado,
				$buttons
			);
		} // /foreach

		echo json_encode($result);
	}

	public function getSelectedMemberInfo($id) 
	{
		if($id) {
			$data = $this->mpregunta->fetchMemberData($id);
			echo json_encode($data);
		}
	}

	public function edit($id = null) 
	{
		if($id) {
			$validator = array('success' => false, 'messages' => array());

			$config = array(
		    array(
	        'field' => 'editPregunta',
	        'label' => 'Pregunta',
	        'rules' => 'trim|required'
		    )
			);

			$this->form_validation->set_rules($config);
			$this->form_validation->set_error_delimiters('<p class="text-danger">','</p>');

			if($this->form_validation->run() === true) {

				$editMember = $this->mpregunta->edit($id); 

				if($editMember === true) {
					$validator['success'] = true;
					$validator['messages'] = "Actualizado exitosamente";
				} else {
					$validator['success'] = false;
					$validator['messages'] = "Error al actualizar la información";
				}			
			} 
			else {
				$validator['success'] = false;
				foreach ($_POST as $key => $value) {
					$validator['messages'][$key] = form_error($key);	
				}			
			}

			echo json_encode($validator);
		}
	}

	public function remove($id = null)
	{
		if($id) {
			$validator = array('success' => false, 'messages' => array());

			$removeMember = $this->mpregunta->remove($id);
			if($removeMember === true) {
				$validator['success'] = true;
				$validator['messages'] = "Eliminado exitosamente";
			}
			else {
				$validator['success'] = true;
				$validator['messages'] = "Eliminado exitosamente";
			}

			echo json_encode($validator);
		}
	}

}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */