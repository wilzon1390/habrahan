<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Welcome extends CI_Controller {

	public function __construct() {
		parent::__construct();

		//form -validation
		$this->load->library('form_validation');

		$this->load->model('model_member');
	}

	public function index()
	{
		$this->load->view('layout/header');
		$this->load->view('admin/home');
		$this->load->view('layout/footer');
	}

	public function create() 
	{

		$validator = array('success' => false, 'messages' => array());

		$config = array(
	    array(
        'field' => 'txtDimension',
        'label' => 'Dimensión',
        'rules' => 'trim|required'
	    )
		);

		$this->form_validation->set_rules($config);
		$this->form_validation->set_error_delimiters('<p class="text-danger">','</p>');

		if($this->form_validation->run() === true) {

			$createMember = $this->model_member->create(); 

			if($createMember === true) {
				$validator['success'] = true;
				$validator['messages'] = "Agregado exitosamente";
			} else {
				$validator['success'] = false;
				$validator['messages'] = "Error al actualizar la información";
			}			
		} 
		else {
			$validator['success'] = false;
			foreach ($_POST as $key => $value) {
				$validator['messages'][$key] = form_error($key);	
			}			
		}

		echo json_encode($validator);
	}

	public function fetchMemberData() 
	{
		$result = array('data' => array());

		$data = $this->model_member->fetchMemberData();
		foreach ($data as $key => $value) {

			// active 
		 	if($value['estado_dim'] == 0) {
		 		// deactivate dimension
		 		$estado = "<label class='label label-danger'>Inactivo</label>"; 		
		 	} else { 		
		 		// activate dimension
		 		$estado = "<label class='label label-success'>Activo</label>";
		 	}
			// button
			$buttons = '
			<div class="btn-group">
			  <button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
			    Acción <span class="caret"></span>
			  </button>
			  <ul class="dropdown-menu">
			    <li><a type="button" onclick="editMember('.$value['id_dim'].')" data-toggle="modal" data-target="#editMemberModal">Editar</a></li>
			    <li><a type="button" onclick="removeMember('.$value['id_dim'].')" data-toggle="modal" data-target="#removeMemberModal">Eliminar</a></li>			    
			  </ul>
			</div>
			';

			$result['data'][$key] = array(
				$value['id_dim'],
				$value['nom_dim'],
				$value['valor_dim'],
				$estado,
				$buttons
			);
		} // /foreach

		echo json_encode($result);
	}

	public function getSelectedMemberInfo($id) 
	{
		if($id) {
			$data = $this->model_member->fetchMemberData($id);
			echo json_encode($data);
		}
	}

	public function edit($id = null) 
	{
		if($id) {
			$validator = array('success' => false, 'messages' => array());

			$config = array(
		    array(
	        'field' => 'editDimension',
	        'label' => 'Dimension',
	        'rules' => 'trim|required'
		    )
			);

			$this->form_validation->set_rules($config);
			$this->form_validation->set_error_delimiters('<p class="text-danger">','</p>');

			if($this->form_validation->run() === true) {

				$editMember = $this->model_member->edit($id); 

				if($editMember === true) {
					$validator['success'] = true;
					$validator['messages'] = "Actualizado exitosamente";
				} else {
					$validator['success'] = false;
					$validator['messages'] = "Error al actualizar la información";
				}			
			} 
			else {
				$validator['success'] = false;
				foreach ($_POST as $key => $value) {
					$validator['messages'][$key] = form_error($key);	
				}			
			}

			echo json_encode($validator);
		}
	}

	public function remove($id = null)
	{
		if($id) {
			$validator = array('success' => false, 'messages' => array());

			$removeMember = $this->model_member->remove($id);
			if($removeMember === true) {
				$validator['success'] = true;
				$validator['messages'] = "Eliminado exitosamente";
			}
			else {
				$validator['success'] = true;
				$validator['messages'] = "Eliminado exitosamente";
			}

			echo json_encode($validator);
		}
	}

}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */