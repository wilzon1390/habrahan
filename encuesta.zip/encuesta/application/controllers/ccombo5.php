<?php
	/**
	 * 
	 */
	class Ccombo5 extends CI_Controller
	{
		
		function __construct()
		{
			parent::__construct();
			$this->load->model('mcombo5');
		}

		public function getCombo5(){
			$s = $this->input->post('estado_preg');
			$resultado = $this->mcombo5->getCombo5($s);

			echo json_encode($resultado);
		}
	}
?>