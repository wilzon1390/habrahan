<?php
	/**
	 * 
	 */
	class Ccombo4 extends CI_Controller
	{
		
		function __construct()
		{
			parent::__construct();
			$this->load->model('mcombo4');
		}

		public function getCombo4(){
			$s = $this->input->post('estado_in');
			$resultado = $this->mcombo4->getCombo4($s);

			echo json_encode($resultado);
		}
	}
?>