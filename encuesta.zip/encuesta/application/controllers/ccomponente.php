<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Ccomponente extends CI_Controller {

	public function __construct() {
		parent::__construct();

		//form -validation
		$this->load->library('form_validation');

		$this->load->model('mcomponente');
	}

	public function index()
	{
		$this->load->view('layout/header');
		$this->load->view('admin/vcomponente');
		$this->load->view('layout/footer');
	}

	public function create() 
	{

		$validator = array('success' => false, 'messages' => array());

		$config = array(
	    array(
        'field' => 'txtComponente',
        'label' => 'Componente',
        'rules' => 'trim|required'
	    )
		);

		$this->form_validation->set_rules($config);
		$this->form_validation->set_error_delimiters('<p class="text-danger">','</p>');

		if($this->form_validation->run() === true) {

			$createMember = $this->mcomponente->create(); 

			if($createMember === true) {
				$validator['success'] = true;
				$validator['messages'] = "Agregado exitosamente";
			} else {
				$validator['success'] = false;
				$validator['messages'] = "Error al actualizar la información";
			}			
		} 
		else {
			$validator['success'] = false;
			foreach ($_POST as $key => $value) {
				$validator['messages'][$key] = form_error($key);	
			}			
		}

		echo json_encode($validator);
	}

	public function fetchMemberData() 
	{
		$result = array('data' => array());

		$data = $this->mcomponente->fetchMemberData();
		$i=0;
		foreach ($data as $key => $value) {
			$i++;
			// active 
		 	if($value['estado_com'] == 0) {
		 		// deactivate dimension
		 		$estado = "<label class='label label-danger'>Inactivo</label>"; 		
		 	} else { 		
		 		// activate dimension
		 		$estado = "<label class='label label-success'>Activo</label>";
		 	}
			// button
			$buttons = '
			<div class="btn-group">
			  <button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
			    Acción <span class="caret"></span>
			  </button>
			  <ul class="dropdown-menu">
			    <li><a type="button" onclick="editMember('.$value['id_com'].')" data-toggle="modal" data-target="#editMemberModal">Editar</a></li>
			    <li><a type="button" onclick="removeMember('.$value['id_com'].')" data-toggle="modal" data-target="#removeMemberModal">Eliminar</a></li>			    
			  </ul>
			</div>
			';

			$result['data'][$key] = array(
				$i,
				$value['nom_dim'],
				$value['nom_com'],
				$value['valor_com'],
				$estado,
				$buttons
			);
		} // /foreach

		echo json_encode($result);
	}

	public function fetchMemberData2() 
	{
		$result = array('data' => array());

		$data = $this->mcomponente->fetchMemberData2();
		$i=0;
		foreach ($data as $key => $value) {
			$i++;
			//contar registros componentes
			$cont = $this->mcomponente->fetchMemberData2($value['id_dim']);
			// active 
		 	if($value['estado_dim'] == 0) {
		 		// deactivate dimension
		 		$estado = "<label class='label label-danger'>Inactivo</label>"; 		
		 	} else { 		
		 		// activate dimension
		 		$estado = "<label class='label label-success'>Activo</label>";
		 	}
		 	//check box
		 	$check='<input type="checkbox" value="'.$value['id_dim'].'" id="che" name="'.$value['id_dim'].'" class="selectall">';
			// button
			$buttons = '
			<div class="btn-group">
			  <button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
			    Acción <span class="caret"></span>
			  </button>
			  <ul class="dropdown-menu">
			    <li><a type="button" onclick="editMember('.$value['id_dim'].')" data-toggle="modal" data-target="#editMemberModal">Editar</a></li>
			    <li><a type="button" onclick="removeMember('.$value['id_dim'].')" data-toggle="modal" data-target="#removeMemberModal">Eliminar</a></li>			    
			  </ul>
			</div>
			';

			$result['data'][$key] = array(
				$check,
				$i,
				$value['nom_dim'],				
				$cont,
				$estado
			);
		} // /foreach

		echo json_encode($result);
	}

	public function getSelectedMemberInfo($id) 
	{
		if($id) {
			$data = $this->mcomponente->fetchMemberData($id);
			echo json_encode($data);
		}
	}

	public function edit($id = null) 
	{
		if($id) {
			$validator = array('success' => false, 'messages' => array());

			$config = array(
		    array(
	        'field' => 'editComponente',
	        'label' => 'Componente',
	        'rules' => 'trim|required'
		    )
			);

			$this->form_validation->set_rules($config);
			$this->form_validation->set_error_delimiters('<p class="text-danger">','</p>');

			if($this->form_validation->run() === true) {

				$editMember = $this->mcomponente->edit($id); 

				if($editMember === true) {
					$validator['success'] = true;
					$validator['messages'] = "Actualizado exitosamente";
				} else {
					$validator['success'] = false;
					$validator['messages'] = "Error al actualizar la información";
				}			
			} 
			else {
				$validator['success'] = false;
				foreach ($_POST as $key => $value) {
					$validator['messages'][$key] = form_error($key);	
				}			
			}

			echo json_encode($validator);
		}
	}

	public function remove($id = null)
	{
		if($id) {
			$validator = array('success' => false, 'messages' => array());

			$removeMember = $this->mcomponente->remove($id);
			if($removeMember === true) {
				$validator['success'] = true;
				$validator['messages'] = "Eliminado exitosamente";
			}
			else {
				$validator['success'] = true;
				$validator['messages'] = "Eliminado exitosamente";
			}

			echo json_encode($validator);
		}
	}

}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */