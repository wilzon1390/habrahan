<?php
	/**
	 * 
	 */
	class Ccombo1 extends CI_Controller
	{
		
		function __construct()
		{
			parent::__construct();
			$this->load->model('mcombo1');
		}

		public function getCombo1(){
			$s = $this->input->post('estado_dim');
			$resultado = $this->mcombo1->getCombo1($s);

			echo json_encode($resultado);
		}
	}
?>