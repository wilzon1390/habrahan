<?php
	/**
	 * 
	 */
	class Ccombo3 extends CI_Controller
	{
		
		function __construct()
		{
			parent::__construct();
			$this->load->model('mcombo3');
		}

		public function getCombo3(){
			$s = $this->input->post('estado_cri');
			$resultado = $this->mcombo3->getCombo3($s);

			echo json_encode($resultado);
		}
	}
?>