<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Ccuestionario extends CI_Controller {

	public function __construct() {
		parent::__construct();

		//form -validation
		$this->load->library('form_validation');

		$this->load->model('mcuestionario');
	}

	public function index(){
		$this->load->view('cuestionario/vcuestionario');
	}

	public function create(){
	}

	public function fetchMemberData(){
		$result = array('data' => array());

		$data = $this->mcuestionario->fetchMemberData();
		$i=0;
		foreach ($data as $key => $value) {
			$respuesta="";
			//seleccionando repuestas de cada pregunta
			$data2 = $this->mcuestionario->fetchMemberData2($value['id_preg']);
			foreach ($data2 as $key2 => $value2){
				$respuesta .= '<input type="radio" class="ra" value="'.$value2['id_res'].'" name="'.$value['id_preg'].'" id="'.$value['id_preg'].$value2["id_res"].'">
					<label for="">'.$value2["nom_res"].'</label>&nbsp;&nbsp;&nbsp; ';
			}
			//imprimiendo preguntas en la tabla
			$i++;
			$result['data'][$key] = array(
				$i,
				$value['nom_preg'],
				$respuesta
			);
		} // /foreach

		echo json_encode($result);
	}

	public function edit($id = null){
	}
}

