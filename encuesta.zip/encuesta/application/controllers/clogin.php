<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Clogin extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->model('mlogin');
	}

	function ingresar(){
		$email = $this->input->post("email");
		$password= $this->input->post("password");
		$resp = $this->mlogin->login($email, $password);
		if($resp){
			$data = array(
				'idUsuario' => $resp->idUsuario,
				'nomUsuario' => $resp->nomUsuario
			);
			 $resultado = $resp->nivel_usuario;
			$this->session->set_userdata($data);
			echo $resultado;	
		}
		else{
			echo "error";
		}
	}

	function cerrar(){
		$this->session->sess_destroy();
	}
}